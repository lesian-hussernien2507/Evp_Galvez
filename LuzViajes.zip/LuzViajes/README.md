# Luz Tours

App movil de una agencia de viajes hecha con React Native (Expo) y Expo Router con menu lateral (Drawer).

## Pantallas
Splash (3 segundos), Inicio, Paquetes y Contactos.

## Instalacion y ejecucion
```bash
npm install
npx expo start
```

## Generar el APK
```bash
npm install -g eas-cli
eas login
eas init
eas build -p android --profile preview
```

Creado por Luz Galvez.
